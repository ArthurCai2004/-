#pragma once
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define OVERFLOW -1
#define SUCCESS 1
#define UNSUCCESS 0
#define UNVISITED 0
#define VISITED 1
#define MAX 20
#define SELECTED 1
#define UNSELECTED 0
#define INFINITY 100
typedef int Status;

