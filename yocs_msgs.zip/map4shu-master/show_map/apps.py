from django.apps import AppConfig


class ShowMapConfig(AppConfig):
    name = 'show_map'
